#include "poly.h"
#include<math.h>
void insert_at_end(List *list, int data) 
{
	Node *temp;
	Node *newnode;
	newnode= (Node *)malloc(sizeof(Node));
	newnode->data=data;
	newnode->link=NULL;
	if(list->head==NULL)
	{
		list->head=newnode;
		list->number_of_nodes=1;
		return;
	}
	temp=list->head;
    while(temp->link!=NULL)
	     temp=temp->link;
    temp->link=newnode;
	list->number_of_nodes=list->number_of_nodes+1;
}

long long int evaluate(List *list, int x)
{   Node *temp;
   long long int result=0;
    temp=list->head;
    int i=0;
    while(temp!=NULL)
    { result+=(temp->data)*(pow(x,i));
      temp=temp->link;
      i=i+1;}
    return result;
}
