#include"dll.h"
int count_nodes(List* dll)
{
Node *temp;
int i=0;
temp=dll->head;
while(temp!=NULL)
{
   i=i+1;
   temp=temp->next;
}
return i;
}

void insert_front(List* dll, int data)
{    Node *temp;
    temp=create_node(data);
    if(dll->head==NULL)
    { 
      dll->tail=temp;
      dll->head=temp; 
      dll->number_of_nodes=dll->number_of_nodes+1;
    }
   else
   {
       temp->next=dll->head;
       dll->head->prev=temp;
       dll->head=temp;
       dll->number_of_nodes=dll->number_of_nodes+1;
   }
   
}

void dllist_delete_beginning(List* list)
{   Node *temp;
    temp=list->head;
    list->head=(list->head)->next;
    (list->head)->prev=NULL;
    free(temp);
    list->number_of_nodes=list->number_of_nodes-1;
}


void position_delete(List* dll, int pos)
{
    Node *prev,*curr;
    if(pos==1)
    {
      Node *temp;
      temp=dll->head;
      dll->head=(dll->head)->next;
      (dll->head)->prev=NULL;
      free(temp);
      dll->number_of_nodes=dll->number_of_nodes-1;
      return;
    }
    else if(pos==dll->number_of_nodes)
    {
       Node *temp;
       while(temp->next!=NULL)
       {
           temp=temp->next;
       }
       
       temp->prev->next=NULL;
       free(temp);
       dll->number_of_nodes=dll->number_of_nodes-1;

       return;
    }







}

int search_list(List* dll,int key)
{
    




}


void reverse_list(List* dll)
{
    




}


