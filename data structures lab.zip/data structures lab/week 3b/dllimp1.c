#include"dll.h"
int count_nodes(List* dll)
{
	int i = 0;
    Node* temp = dll->head;
    if (temp == NULL)
    {
        return 0;
    }
    else
    {
        while(temp != NULL)
        { 
            i++;
            temp = temp->next;
        }
        return i;
    }
}

void insert_front(List* dll, int data)
{
    Node* temp = (Node*)malloc(sizeof(Node));
    temp->data = data;
    temp->next = NULL;
    temp->prev = NULL;
    Node* p = dll->head;
    if (p == NULL)
    {
        dll->head = temp;
        (dll->number_of_nodes)++;
    }
    else
    {
        temp->next = p;
        p->prev = temp;
        dll->head = temp;
        (dll->number_of_nodes)++;
    }
    
}


void dllist_delete_beginning(List* list)
{
    Node* p = list->head;
    if(p == NULL)
    {
        
    }
    else if(p->next == NULL)
    {
        list->head = NULL;
        (list->number_of_nodes)--;
        free(p);
    }
    else
    {
        list->head = p->next;
        p->next->prev = NULL;
        p->next = NULL;
        free(p);
        (list->number_of_nodes)--;
    }
}


void position_delete(List* dll, int pos)
{
    Node* p = dll->head;
    Node* q = dll->head;
    Node* r = dll->head;
    if(pos > dll->number_of_nodes)
    {

    }
    else if (pos == 0)
    {
        
        dll->head = NULL;
        free(p);
        (dll->number_of_nodes)--;
    }
    
    else
    {
        pos++;
        p = dll->head;
        int i = 1;
        while (i < pos - 1)
        {
            p = p->next;
            i++;
        }
        q = p->next;
        r = q->next;
        
        p->next = r;
        r->prev = p;
        q->next = NULL;
        q->prev = NULL;
        free(q);
        (dll->number_of_nodes)--;   
    }
    
}

int search_list(List* dll,int key)
{
    Node* p = dll->head;
    int i = 0;
    while(p != NULL)
    {
        if (p->data == key)
        {
            return i;
        }
        else
        {
            p = p->next;
            i++;
        }
        
    }
    return -1;
}


void reverse_list(List* dll)
{
    Node* p = dll->head;
    int n = dll->number_of_nodes;
    int ar[n];
    int i = 0;
    while (p != NULL)
    {
        ar[i] = p->data;
        i++;
        p = p->next;
    }
    p = dll->head;
    while (p != NULL)
    {
        p->data = ar[n-1];
        n--;
        p = p->next;
    }
    
}