#include "hash.h"
HashTable *create_table(int size)
{
    //TODO
}

void insert(HashTable *htable, int element)
{
    //TODO
}

int search(HashTable *htable, int element)
{
    //TODO
}

void delete (HashTable *htable, int element)
{
    //TODO
}


void destroy_table(HashTable *htable)
{
    //TODO

}
