#include "5a.h"

static Node* create_Node(int data, Node* link)
{



}


void list_initialize(List* ptr_list) 
{
//TODO - initialize structure members to default values
}


void list_insert_front(List* ptr_list, int data) 
{
//TODO - perform linked list implementation of push operation.
}


const int Node_get_data(Node *Node_ptr) 
{
//TODO - return the top most element
}


void list_delete_front(List* ptr_list) 
{
//TODO - perform linked list implementation of pop operation.
}


void list_destroy(List* ptr_list) 
{
//TODO - free the allocated space
}

void Stack_initialize(Stack *ptr_Stack) 
{
//TODO - get the memory allocation for stack, and intern call list initialize
}

void Stack_push(Stack *ptr_Stack, int key) 
{
//TODO	 - call the function list_insert_front
}

void Stack_pop(Stack *ptr_Stack) 
{
//TODO- call the function list_delete_front
}

int Stack_is_empty(Stack *ptr_Stack) 
{
//TODO	- return 0 if stack is not empty
}

const int Stack_peek(Stack *ptr_Stack) 
{
//TODO	- return the top most element of the stack
}

void Stack_destroy(Stack *ptr_Stack)
 {
//TODO	- deallocate
}

int match_parenthesis(const char* string)
{
//TODO - implement the code to match paranthesis in a string which is passed as a parameter.
}	


 

